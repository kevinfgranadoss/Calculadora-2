/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calc;

public class Trigonométrica extends Calculador{
    void seno(){
        resultado=(float)Math.sin(operador1);
    }
    void coseno(){
        resultado=(float)Math.cos(operador1);
    }
    void tangente(){
        resultado=(float)Math.tan(operador1);
    }
}
